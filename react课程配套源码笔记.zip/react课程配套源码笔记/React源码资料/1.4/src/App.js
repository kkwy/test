import React from 'react'

export default class App extends React.Component{
    render(){
        return (
            <div>
                你好，我是重写的，不是快速生成
            </div>
        )
    }
}


