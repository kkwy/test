
import styles from './setlanguage.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>语言设置页面</h1>
    </div>
  );
}
