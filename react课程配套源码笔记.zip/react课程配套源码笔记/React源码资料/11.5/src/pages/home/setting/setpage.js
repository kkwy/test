
import styles from './setpage.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>页面设置</h1>
    </div>
  );
}
