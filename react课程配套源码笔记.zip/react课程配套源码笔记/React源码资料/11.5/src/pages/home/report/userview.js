
import styles from './userview.css';

export default function() {
  return (
    <div className={styles.normal}>
      <h1>浏览用户人次报表页面</h1>
    </div>
  );
}
